#P55

list =[]
list2 =[56,4.0,'string',True]
list3 =[1,2,3,4,5,6]
list4 =['python','C','Java']

print(list2[0])
print(list4[2])
print(len(list2))

print(sum(list3))
print(max(list3))
print(min(list3))
list5  = [88,99]
print(4 in list3)
print(list3+ list5) #chuan jie
print(list5*3)

print(type(list2))

