#59

str1 ='Python C Java C#'
list1 = str1.split()

print(list1)

str1 ='Python,C,Java,C#'
list1 = str1.split(',')
for val in list1:
    print(val)

