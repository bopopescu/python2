
set1 = {'python', 'java', 'c', 'c#'}

for data in set1:
    print(data)